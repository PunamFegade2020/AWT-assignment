//JsAssignment 2
//Que 1)With example illustrate variable and function closure in javascript

function Counter()
{
  var counter =0;
  function increaseCounter()
  {
    return count++;
  };
  var count = counter();
  console.log(count());
  console.log(count());
  console.log(count());
}

//Que 2) Write a javascript function named reverse which takes a string argument and returns the
//reversed string.

function reverseString(s)
{
  return s.split("").reverse().join("");
  
}
console.log(reverseString("Punam"));

//Que 3)Given a javascript array of objects having a radius property as shown [{radius: 5}, {radius: 9},
//{radius: 2}] , write a comparator function to sort it.

function fun1()
{
  var arr = [ 5, 9, 2];
  console.log(arr.sort());
}
fun1();

//Que 4)Write a Javascript program to sort elements of an array using sorting algorithm

function animals()
{
  var arr= ["Tiger","Deer","Lion","Camel"];
             console.log(arr.sort());
}
animals();


//Que 5)Write a javascript function named length_of_array , which takes an array as argument and returns the number of elements in that array (as opposed to what is given by
//the length property of the array). Remember undefined can also be an element if it is explicitly set at someindex, e.g. x[5] = undefined; This undefined should be 
//counted, but elements which are not present in the array (as arrays can be sparse), should not be counted.

var array=["first","second","third"];
array.forEach(function(element)
             {
  console.log(element);
  
})
if(array[2] === undefined)
  {
    console.log("array[2] is undefined");
    
  }
array = ["first","second",undefined,"third"];
array.forEach(function (element)
{
          console.log(element);
})


//Que 6)With suitable example explain OOL concepts in javascript like Inheritance, Constructor,Encapsulation and Abstraction .

var Person = function(firstname,lastname)
{
  this.firstname= firstname;
  this.lastname= lastname;
};
Person.prototype.learn = function()
{
  console.log(this.firstname + " is learning");
};
Person.prototype.sayhello = function()
{
  console.log("Hello I am "+this.firstname);
};
function Student(firstname,subject,lastname)
{
  Person.call(this,firstname,lastname);
  this.subject =subject;
 }
Student.prototype =Object.create(Person.prototype);

Student.prototype.constructor =Student;
Student.prototype.sayhello =function()
{
  console.log("Hello "+this.firstname +" "+this.subject + " "+this.lastname);
};

Student.prototype.saygoodby =function()
{
  console.log("GoodBye");
};

var stud =new Student("Punam", "Patil","Java");
stud.sayhello();
stud.learn();
stud.saygoodby();






































