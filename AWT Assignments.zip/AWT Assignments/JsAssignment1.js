//Js-Assignment 1

//Que 1.WAP to illustrate implementation of functions in javascript.
 function sum(a,b)
	{
	return a+b;
	}
	console.log(sum(8,4));
	
//Que 2.WAP to illustrate the declaration of object, assignment of value and display it

var person={ personFirstname:"Punam", personLastname:"Patil",personage:"25" ,
FullName:function()
{
  return  this.personFirstname +this.personLastname
}
 };

console.log("Personf FirstName and LastName is:"+person.personFirstname + person.personLastname );

console.log("FullName is:"+ person.FullName());

//Que3.WAP to illustrate declaration of array , assignment of value to an array and display it.


var Flowers=["Lotus","Rose","Water-lily","Sunflower","Marigold"];

console.log(Flowers);


//Que 4.Write a javascript function named is_integer which checks if the passed argument is an integer.
//You can use any mathematical operator or functions defined in the Math object.

function isinteger(a)
{
  if(isNaN(x))
    {
      console.log("Is not a Number");
    }
  else
    {
      console.log("Is a Number");
    }
}
isinteger(8);

//Que 5.Using the forEach function defined for an array, find the sum of the array of numbers. [ function
//add_all(arr) {...} ]

function add1(arr)
{
  var sum=0;
  for(var i in arr)
    {
      sum=sum+arr[i];
    }
  return sum;
}
arr=[2,4,6,8,10];
add1(arr);


//Que 6.Write a JavaScript program to convert temperatures to and from celsius, fahrenheit. [ Use the
//formula : c/5 = (f-32)/9, where c = temperature in celsius and f = temperature in fahrenheit]

function tocelicus(f)
{
  return(5/9) *(f-32);
}
tocelicus(200)
//**************************************

function tofahrenheit(c)
{
  return ((c*1.8)+32);
}
tofahrenheit(200)

//Que 7.Write a factorial function that returns the factorial of a given number, n. Make sure you return the
//calculated value and not just print it. [ function factorial(n){...} ]

function fact(a)
{
var b=1;
  while(a>0)
    {
      b=b*a;
      a--;
    }
  return b;
}
fact(5)


//Que 8.Write a javascript function that converts a given amount of money into coins of denominations (1,
//2, 5, 10 and 25). [ function convert_to_coins(amount) {...} ]. You may choose to print the coin
//denominations used on the console. E.g. convert_to_coins(87) should print 25 25 25 10 2


function amt1(amount,coin)
{
  if(amount === 0)
    {
      return [];
    }
  else
    {
      if(amount >= coin[0])
        {
          a = (amount - coin[0]);
          return [coin[0]].concat(amt1(x,coin));
        }
      else
        {
          coin.shift();
          return amt1(amount,coin);
        }
    }
}
console.log(amt1(87,[25,10,5,2,1]));
coin =[25,10,5,2,1];
amt1(87,coin);























